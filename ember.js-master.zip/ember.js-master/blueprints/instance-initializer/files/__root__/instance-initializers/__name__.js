export function initialize(/* appInstance */) {
}

export default {
  initialize
};
