<%= importComponent %>
<%= importTemplate %>
export default <%= defaultExport %>
