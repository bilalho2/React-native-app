export { default } from '<%= templateModulePath %>';
