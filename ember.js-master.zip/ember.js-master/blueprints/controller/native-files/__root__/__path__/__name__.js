import Controller from '@ember/controller';

export default class <%= classifiedModuleName %>Controller extends Controller {
}
