export function initialize(/* application */) {
}

export default {
  initialize
};
