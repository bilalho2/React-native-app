'use strict';

module.exports = {
  description: 'Generates an initializer.',
};
