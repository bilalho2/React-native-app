import Service from '@ember/service';

export default class <%= classifiedModuleName %>Service extends Service {
}
