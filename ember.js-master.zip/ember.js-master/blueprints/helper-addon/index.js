'use strict';

module.exports = require('../-addon-import');
