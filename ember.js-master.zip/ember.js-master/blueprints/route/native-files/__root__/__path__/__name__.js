import Route from '@ember/routing/route';

export default class <%= classifiedModuleName %>Route extends Route {
}
