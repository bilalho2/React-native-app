export default function fooBar() {
  return true;
}
