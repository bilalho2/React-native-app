export default function fooBarBaz() {
  return true;
}
