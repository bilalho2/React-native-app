export { default } from 'my-addon/helpers/foo/bar-baz';
