import Route from '@ember/routing/route';

export default class ParentChildRoute extends Route {
}
