import Service from '@ember/service';

export default class FooService extends Service {
}
