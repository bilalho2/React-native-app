import Controller from '@ember/controller';

export default class FooBarController extends Controller {
}
