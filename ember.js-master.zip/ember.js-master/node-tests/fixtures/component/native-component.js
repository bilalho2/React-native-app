import Component from '@glimmer/component';

export default class FooComponent extends Component {
}
