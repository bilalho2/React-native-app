import Component from '@ember/component';
import layout from '../templates/components/x-foo';

export default Component.extend({
  layout
});
