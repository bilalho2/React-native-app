import { expect } from 'chai';
import { describe, it } from 'mocha';
import fooBar from 'my-app/utils/foo-bar';

describe('Unit | Utility | foo-bar', function() {
  // TODO: Replace this with your real tests.
  it('works', function() {
    let result = fooBar();
    expect(result).to.be.ok;
  });
});
