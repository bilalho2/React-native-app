import fooBar from 'dummy/utils/foo-bar';
import { module, test } from 'qunit';

module('Unit | Utility | foo-bar');

// TODO: Replace this with your real tests.
test('it works', function(assert) {
  let result = fooBar();
  assert.ok(result);
});
