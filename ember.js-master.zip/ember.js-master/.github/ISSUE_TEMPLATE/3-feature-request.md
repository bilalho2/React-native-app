---
name: 💬 Feature request
about: Please, follow the RFC process for feature requests (https://github.com/emberjs/rfcs).
title: "[Feature] Feature request"
labels: ''
assignees: ''

---

Ember has an RFC process for feature requests. Please, do not create a feature request here and follow the RFC process described in https://github.com/emberjs/rfcs.
