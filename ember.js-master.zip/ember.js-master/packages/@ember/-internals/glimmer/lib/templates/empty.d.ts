import { TemplateFactory } from '@glimmer/interfaces';
declare const TEMPLATE: TemplateFactory;
export default TEMPLATE;
