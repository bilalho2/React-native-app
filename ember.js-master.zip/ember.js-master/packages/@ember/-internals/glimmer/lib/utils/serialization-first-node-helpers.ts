export { isSerializationFirstNode } from '@glimmer/runtime';
