const allSupportedBrowsers = [
  'last 2 Chrome versions',
  'last 2 Firefox versions',
  'Safari 12',
  'last 2 Edge versions',
];

const modernBrowsers = [
  'last 1 Chrome versions',
  'last 1 Firefox versions',
  'last 1 Safari versions',
];

module.exports = {
  allSupportedBrowsers,
  modernBrowsers,
};
